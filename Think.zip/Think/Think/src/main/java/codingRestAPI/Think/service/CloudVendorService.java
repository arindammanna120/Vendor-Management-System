package codingRestAPI.Think.service;

import codingRestAPI.Think.model.cloudVendor;

import java.util.List;

public interface CloudVendorService {

    public String createCloudVendor(cloudVendor vendor);
    public String updateCloudVendor(cloudVendor vendor);
    public String deleteCloudVendor(String cloudVendorId);
    public cloudVendor getCloudVendor(String cloudVendorId);

    public List<cloudVendor> getAllCloudVendors();
}
