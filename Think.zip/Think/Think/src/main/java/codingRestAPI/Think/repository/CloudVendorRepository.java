package codingRestAPI.Think.repository;

import codingRestAPI.Think.model.cloudVendor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CloudVendorRepository extends JpaRepository<cloudVendor,String> {
}
