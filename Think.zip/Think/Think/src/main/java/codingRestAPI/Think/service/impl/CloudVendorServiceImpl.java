package codingRestAPI.Think.service.impl;

import codingRestAPI.Think.exception.CloudVendorNotFoundException;
import codingRestAPI.Think.model.cloudVendor;
import codingRestAPI.Think.repository.CloudVendorRepository;
import codingRestAPI.Think.service.CloudVendorService;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CloudVendorServiceImpl implements CloudVendorService {

    // repository layer actually talking to database so it must


    CloudVendorRepository cloudVendorRepository;

    public CloudVendorServiceImpl(CloudVendorRepository cloudVendorRepository) {
        this.cloudVendorRepository = cloudVendorRepository;
    }




    @Override
    public String createCloudVendor(cloudVendor vendor) {

        cloudVendorRepository.save(vendor);
        return "Success";
    }

    @Override
    public String updateCloudVendor(cloudVendor vendor) {
      // more business logic write here
        cloudVendorRepository.save(vendor);
        return "Successfully Updated";
    }

    @Override
    public String deleteCloudVendor(String cloudVendorId) {
        cloudVendorRepository.deleteById(cloudVendorId);
        return "deleted successfully";
    }

    @Override
    public cloudVendor getCloudVendor(String cloudVendorId) {

        if(cloudVendorRepository.findById(cloudVendorId).isEmpty())
            throw new CloudVendorNotFoundException("Requested clod vendor does not exist");

        return cloudVendorRepository.findById(cloudVendorId).get();
    }

    @Override
    public List<cloudVendor> getAllCloudVendors() {

        return cloudVendorRepository.findAll();
    }
}
