package codingRestAPI.Think.controller;

import codingRestAPI.Think.ResponsePackage.ResponseHandler;
import codingRestAPI.Think.model.cloudVendor;
import codingRestAPI.Think.service.CloudVendorService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cloudVendor")
public class CloudApiService {

    CloudVendorService cloudVendorService;

    public CloudApiService(CloudVendorService cloudVendorService)
    {
        this.cloudVendorService = cloudVendorService;
    }







    // Read specific cloud vendor details from DB
    @GetMapping("/{vendorId}")
     public ResponseEntity<Object> getApi(@PathVariable("vendorId") String vendorId){

       return ResponseHandler.responseBuilder("Required Vendor Details are given here",
                HttpStatus.OK,cloudVendorService.getCloudVendor(vendorId));




    }

     // read all cloud vendor details from DB
    @GetMapping("")
    public List<cloudVendor> getAllApi(){

        return cloudVendorService.getAllCloudVendors();


    }


@PostMapping
    public String postApi(@RequestBody cloudVendor Vendor){

    cloudVendorService.createCloudVendor(Vendor);
    return "cloud vendor create successfully..";
}

@PutMapping
    public String UpdateCloudVendor(@RequestBody cloudVendor Vendor){

        cloudVendorService.updateCloudVendor(Vendor);
        return " cloud Vendor updated successfully";
}

@DeleteMapping("{vendorId}")
    public String DeleteCloudVendor(@PathVariable("vendorId") String vendorId){
        cloudVendorService.deleteCloudVendor(vendorId);
        return "cloud vendor deleted successfully";
}


}
